import http.HttpRequest;
import java.io.File;
import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;

public class Crawler {
	public static void main(String args[]){
		//新建Scanner
		Scanner s = new Scanner(System.in); 
		
		//获取保存验证码图片
		File output = new File("GenImg.jpg");
		HttpRequest img = HttpRequest.get("http://210.42.121.132/servlet/GenImg");
		img.receive(output);
		
		//获取cookie
		String cookie = img.headers().get("Set-Cookie").get(0).split(";")[0];

		//输入账号，密码
		Map<String, String> data = new HashMap<String, String>();
		System.out.println("请输入账号:");
		String id = s.nextLine();
		data.put("id", id);
		
		System.out.println("请输入密码:");
		String pwd = s.nextLine();
		data.put("pwd", pwd);
		
		//人工读取验证码，手动输入
		System.out.println("请输入验证码:");
		String xdvfb = s.nextLine();
		data.put("xdvfb", xdvfb);
		
		//使用账户，密码，验证码登陆
		HttpRequest login = HttpRequest.post("http://210.42.121.132/servlet/Login").header("Cookie", cookie).form(data).followRedirects(false);
		login.body();
		
		//抓取课程数据，并保存	
		File html = new File("Courses.html");
		HttpRequest.get("http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType").header("Cookie", cookie).receive(html);
		
		//关闭Scanner
		s.close();
		
		System.out.println("Finish");
	}
}
