/**
 * Created by terry on 15-9-20.
 */

import com.github.kevinsawicki.http.*;
import java.io.*;

public class GetGrades {
    public static void main(String[] args)
    {
        String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2014:14:03%20GMT+0800%20(CST)";
        String cookie = "JSESSIONID=5C0CE5BA0863C56B5999A94E39F19582.tomcat2";
        String result = getContent(url, cookie);

        File file = new File("./result.html");
        try
        {
            if (!file.exists())
                file.createNewFile();

            FileWriter fileWriter = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(result);
            bufferedWriter.close();
        }
        catch (IOException err)
        {
            err.printStackTrace();
        }
    }

    public static String getContent(String url, String cookie)
    {
        HttpRequest response = HttpRequest.get(url).header("Cookie", cookie);

        if (response.code() == 200)
            return response.body();
        else
            return "error";
    }
}
