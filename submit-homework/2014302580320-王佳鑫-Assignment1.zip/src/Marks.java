import java.io.File;


public class Marks {
	public static void main(String args[]){
		//html�ļ�
		String urlString="http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2021%202015%2000:24:56%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		String filePath="marks.html"; 
		HttpRequest response=HttpRequest.get(urlString);
		
		//cookieģ���¼
		response.header("cookie","JSESSIONID=312BFE25982BF0010CF3FBC8C6ADF93D.tomcat2");
		
		response.receive(new File(filePath));
		
		//css�ļ�
		String urlString1="http://210.42.121.132/css/style.css?v=2.002";
		String filePath1="style.css";
		HttpRequest response1=HttpRequest.get(urlString1);
	    response1.receive(new File(filePath1));
				
		String urlString2="http://210.42.121.132/css/tab.css?v=2.002";
		String filePath2="tab.css";
		HttpRequest response2=HttpRequest.get(urlString2);
		response2.receive(new File(filePath2));
				
		
		
	}
}
