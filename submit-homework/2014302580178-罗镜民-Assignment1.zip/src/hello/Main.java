/*2014302580178
 * �޾���
 * 15-9-19
 * ����
 */

/* Methods explanation.
 * 1.GetImage��get the  CAPTCHAimage from educational administration system website.
 * 2.
 * 3.
 */
package hello;

import java.util.Scanner;
import java.io.*;
import com.github.kevinsawicki.http.*;

public class Main {
	public static void main(String[]args){
		/*int[] oldList = {1, 2, 3, 4, 5};
		reverse(oldList);
		for (int i = 0; i < oldList.length; i++)
		System.out.print(oldList[i] + " ");
	*/
	/*
	 * 
	 * 
	 * 
	 * */	
	GetImage();
	
	}



public static void reverse(int[] list) { 

	list[4] = 1; 
	
}

public static void GetImage(){
	//GetImage��get the  CAPTCHAimage from educational administration system website.
	//
	//
	String url = "http://210.42.121.241/servlet/GenImg";
	HttpRequest response = HttpRequest.get(url);
	String FileName = "1.png";
	response.receive(new File(FileName));
	
}
}

