import java.io.File;


public class Crawler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2019:03:49%20GMT+0800%20(CST)";
		 
		  
		 String fName = "chengji.html";
		 
		 HttpRequest response = HttpRequest.get(url);
		 
		 response.header("Cookie", "JSESSIONID=2E0F0249C25686CF903FFB001DB6DE49.tomcat2");
		 
		 response.receive(new File(fName));
		 
			
}
}
