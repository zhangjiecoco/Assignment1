import java.io.File;

public class MyGrade {
		public static void main(String[] args) {
			//Declare a string called myGradeURL to store the URL where you get the content.
			String myGradeURL="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%2021:54:14%20UTC+0800%202015";
			
			//Declare a variable using class HttpRequest.
			//Use the "get" method to obtain the content from the URL.  
			HttpRequest request=HttpRequest.get(myGradeURL);
			
			//Invoke method header to use cookie information to skip the login process in a web.
			request.header("Cookie", "JSESSIONID=8E6CACE80010AB94C175649166A6430F.tomcat2");
			
			//Declare a string to store the name and the type of the content that you obtain.
			String myFile="test.html";
			//Invoke receive method to transfer it into the form you want.
			request.receive(new File(myFile));
			
	}
}
//http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%2021:54:14%20UTC+0800%202015
//http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun Sep 20 21:54:14 UTC+0800 2015