package homework1;

import java.io.File;

public class Report {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
     String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0";
     String fName ="xiaohao.html";

	 HttpRequest response = HttpRequest.get(url).header("cookie","JSESSIONID=04D7BC45CAF420E650234AEB9AD27816.tomcat2");

	 response.receive(new File("xiaohao.html"));
	    }
	}
	


