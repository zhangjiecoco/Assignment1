package oop.java.assignment1;

import java.io.File;

public class Test {
	public static void main(String[] args){
		//String url = "http://210.42.121.241/servlet/GenImg";
		String url = "http://210.42.121.132/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2013:09:59%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		
		HttpRequest response = HttpRequest.get(url).header("Cookie","JSESSIONID=F4BF373D7332D5EA71E2EECA06AB34AD.tomcat2");
		if(response.ok()){
			response.receive(new File("196.html"));
		}
	}
}