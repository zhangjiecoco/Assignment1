/*import java.net.URL;
import java.io.IOException;
import java.net.MalformedURLException;*/
import java.io.File;
/*import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLConnection;*/

/* ���� 2014302580342 �*/

public class StudentScore {
	public static void main(String args[]){
		
		//��Ҫץ�µ�url
		String urlString[] ={ 
				"http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2021:21:21%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)",
				"http://210.42.121.241/css/style.css?v=2.002",
				"http://210.42.121.241/css/tab.css?v=2.002",
		};
		
		//����ļ���λ��   html����html�ļ����� css����css�ļ����� 
		String filePath[] ={ "html/test.html","css/style.css","css/tab.css"};
		
		//ץȡ��ҳ
		for (int i = 0; i<3; i++){
			HttpRequest response = HttpRequest.get(urlString[i]).header("Cookie","JSESSIONID=202E4859A887C81F326881B1DDA251E7.tomcat2");
			response.receive(new File(filePath[i]));
		}
	}
}
