import java.io.File;


public class MyGrade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2021%202015%2018:19:00%20GMT+0800";
		String test="MyGrade.html";
		HttpRequest response=HttpRequest.get(url);
		response.header("Cookie","JSESSIONID=7B2131FECE58B4E68A5EF409A9034726.tomcat2");
		response.receive(new File(test));
	}

}
