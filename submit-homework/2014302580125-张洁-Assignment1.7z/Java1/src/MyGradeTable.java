import java.io.File;
public class MyGradeTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

int t=0;
while(t<3)
{
	String url="http://210.42.121.241/servlet/"
			+ "Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag"
			+ "=0&t=Tue%20Sep%2022%202015%2020:39:03%20GMT+0800%20"
			+ "(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";//�ɼ�����URL
	HttpRequest response=HttpRequest.get(url);//Get������ȡURL
	response.header("Cookie","JSESSIONID=99AB15A4A0E0339718E68C195257620C.tomcat2");
	String fName="MyGradeTable"+Integer.toString(t)
			+ ".html";//�����ҵĳɼ���
	response.receive(new File(fName));
	t++;
	
}

	}

}
