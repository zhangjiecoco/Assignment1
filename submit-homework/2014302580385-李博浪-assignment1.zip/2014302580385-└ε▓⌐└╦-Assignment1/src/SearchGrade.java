
import java.io.*; 

/**
 * @author ���
 *
 */
public class SearchGrade
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
		// TODO �Զ����ɵķ������
	{
		
		String url="http://210.42.121.134/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2000:51:24%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
		String cookie="JSESSIONID=081594488D648296A239F6EDCC3F4024.tomcat2";
		HttpRequest abc=new HttpRequest(url,"GET");
		abc.header("Cookie",cookie);
		abc.receive(new File("grade.html"));
		

	}
	
}