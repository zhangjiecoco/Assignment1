package java1;
import java.io.File;
public class ImageCrawler {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
       String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sat%20Sep%2019%202015%2016:36:18%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
       HttpRequest request = HttpRequest.get(url).header("Cookie","JSESSIONID=26B9310BBF5964B9C29DA092FE515B6C.tomcat2");
    		 request.receive(new File("test.html"));
	}
}
