package java1;
import java.io.File;
public class MarkCrower {
	public static void main (String[] args){
		 String url ="http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%Sep%21%2015%10:20:44%GMT+0800";
	       HttpRequest request = HttpRequest.get(url).header("Cookie","JSESSIONID=F0974F0098FAC6402F669A0F10D44AA3.tomcat2");
	    	String text="mark.html";	 
	       request.receive(new File(text));
		
	}

}
