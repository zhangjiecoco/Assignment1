import java.io.File;

import com.github.kevinsawicki.http.HttpRequest;


public class ScoreCrawler {
	public static void main(String[] args){
		String url = "http://210.42.121.134/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2016:24:45%20GMT+0800";
		HttpRequest hr = new HttpRequest(url,"GET");
		hr.header("Cookie","JSESSIONID=E00D315C912EE5AFF23F7D1801E00C61.tomcat2; _5t_trace_sid=79d0574f50d2289d6599c042761141db; _5t_trace_tms=1");
		
		
		
		if(hr.ok()){
			File my = new File("Myscore.html");
			hr.receive(my);
		}
	}
}
