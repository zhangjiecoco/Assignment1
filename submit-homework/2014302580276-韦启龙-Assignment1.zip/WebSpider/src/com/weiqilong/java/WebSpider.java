package com.weiqilong.java;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.zip.GZIPInputStream;

/**
 * Created by Jason_Wei(weiqilong) on 2015/9/17.
 */
public class WebSpider {
    private static String cookie = "";

    //use this function to download some resources, like css, image...
    static void getUnprotectedSource(String fileUrl, String saveToFileName) throws Exception {

        URL url = new URL(fileUrl);

        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("GET");
        connection.setDoInput(true);
        connection.setDoOutput(true);
        connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36");

        connection.connect();

        InputStream inputStream = connection.getInputStream();

        byte[] bytes = new byte[1024];

        int length = 0;

        FileOutputStream outputStream = new FileOutputStream(saveToFileName);

        while (length != -1) {

            try {
                length = inputStream.read(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (length != -1) {
                try {
                    //write into file
                    outputStream.write(bytes, 0, length);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        //close stream
        outputStream.close();
        inputStream.close();
    }

    public static void main(String[] args) {

        JFrame mFrame = new JFrame("Simple Web Spider --by Jason Wei(weiqilong)");

        //set window attr
        mFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mFrame.setSize(500, 500);
        mFrame.setVisible(true);

        //use absolute layout
        mFrame.setLayout(null);


        //add labels
        JLabel idLabel = new JLabel();
        mFrame.add(idLabel);
        idLabel.setText("User Name :");
        idLabel.setBounds(120, 70, 80, 20);

        JLabel pwdLabel = new JLabel();
        mFrame.add(pwdLabel);
        pwdLabel.setText("Password :");
        pwdLabel.setBounds(120, 140, 70, 20);

        JLabel codeInputLabel = new JLabel();
        mFrame.add(codeInputLabel);
        codeInputLabel.setText("Input The Code :");
        codeInputLabel.setBounds(120, 210, 100, 20);

        JLabel codeLabel = new JLabel();
        mFrame.add(codeLabel);
        codeLabel.setText("Identifying Code :");
        codeLabel.setBounds(120, 280, 100, 20);

        //add input fields
        JTextField idInput = new JTextField();
        mFrame.add(idInput);
        idInput.setBounds(250, 65, 120, 30);
        idInput.setText("");
        idInput.setBorder(new LineBorder(Color.GRAY));

        JTextField pwdInput = new JTextField();
        mFrame.add(pwdInput);
        pwdInput.setBounds(250, 135, 120, 30);
        pwdInput.setText("");
        pwdInput.setBorder(new LineBorder(Color.GRAY));

        JTextField codeInput = new JTextField();
        mFrame.add(codeInput);
        codeInput.setBounds(250, 205, 120, 30);
        codeInput.setText("");
        codeInput.setBorder(new LineBorder(Color.GRAY));

        //add image container
        JPanel jPanel = new JPanel();
        mFrame.add(jPanel);
        jPanel.setBounds(250, 275, 130, 30);

        //add two buttons
        JButton refreshButton = new JButton("REFRESH");
        mFrame.add(refreshButton);
        refreshButton.setBounds(125, 350, 100, 40);
        refreshButton.setFocusPainted(false);

        JButton okButton = new JButton("OK");
        mFrame.add(okButton);
        okButton.setBounds(250, 350, 100, 40);
        okButton.setFocusPainted(false);


        //add listener to ok button
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {

                //login now
                URL loginUrl = null;
                try {
                    loginUrl = new URL("http://210.42.121.134/servlet/Login");
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                HttpURLConnection login = null;
                try {
                    login = (HttpURLConnection) loginUrl.openConnection();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    login.setRequestMethod("POST");
                } catch (ProtocolException e) {
                    e.printStackTrace();
                }
                login.setInstanceFollowRedirects(true);
                login.setUseCaches(false);
                login.setDoInput(true);
                login.setDoOutput(true);
                login.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
                login.addRequestProperty("Accept-Encoding", "gzip, deflate");
                login.addRequestProperty("Accept-Language", "zh-CN,zh;q=0.8");
                login.addRequestProperty("Cache-Control", "max-age=0");
                login.addRequestProperty("Connection", "keep-alive");
                login.addRequestProperty("Content-Length", "41");
                login.addRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                login.addRequestProperty("Cookie", cookie);
                login.addRequestProperty("Host", "210.42.121.134");
                login.addRequestProperty("Origin", "http://210.42.121.134");
                login.addRequestProperty("Referer", "http://210.42.121.134/");
                login.addRequestProperty("Upgrade-Insecure-Requests", "1");
                login.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36");
                try {
                    login.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                OutputStream writeInfo = null;
                try {
                    writeInfo = login.getOutputStream();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //post login info to server
                String info = "id=" + idInput.getText() + "&pwd=" + pwdInput.getText() + "&xdvfb=" + codeInput.getText();
                try {
                    writeInfo.write(info.getBytes());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    writeInfo.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    writeInfo.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                BufferedReader getResponseInfo = null;
                try {
                    getResponseInfo = new BufferedReader(new InputStreamReader(login.getInputStream()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String responseString = "";
                while (responseString != null) {
                    try {
                        responseString = getResponseInfo.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (responseString != null) {
                        //System.out.println(responseString);
                    }
                }


                //after login, get scores
                URL scoreUrl = null;
                try {
                    scoreUrl = new URL("http://210.42.121.134/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0");
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                HttpURLConnection scoreCon = null;
                try {
                    scoreCon = (HttpURLConnection) scoreUrl.openConnection();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    scoreCon.setRequestMethod("GET");
                } catch (ProtocolException e) {
                    e.printStackTrace();
                }
                scoreCon.setDoInput(true);
                scoreCon.setDoOutput(true);
                scoreCon.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
                scoreCon.addRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
                scoreCon.addRequestProperty("Accept-Language", "zh-CN,zh;q=0.8");
                scoreCon.addRequestProperty("Cache-Control", "max-age=0");
                scoreCon.addRequestProperty("Connection", "keep-alive");
                scoreCon.addRequestProperty("Cookie", cookie);
                scoreCon.addRequestProperty("Host", "210.42.121.134");
                scoreCon.addRequestProperty("Upgrade-Insecure-Requests", "1");
                scoreCon.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36");
                try {
                    scoreCon.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //decode chunked info the server response
                GZIPInputStream gzipInputStream = null;
                try {
                    gzipInputStream = new GZIPInputStream(scoreCon.getInputStream());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                byte[] byteArr = new byte[1024];
                int lengthS = 0;
                FileOutputStream scoreOutput = null;
                try {
                    scoreOutput = new FileOutputStream("./Svlt_QueryStuScore.html");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                while (lengthS != -1) {
                    try {
                        lengthS = gzipInputStream.read(byteArr);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (lengthS != -1) {
                        try {
                            scoreOutput.write(byteArr, 0, lengthS);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                try {
                    scoreOutput.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    gzipInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }


                //if directories don't exist, create them to hold resources
                try {
                    if (!(new File("../css/").isDirectory())) {
                        new File("../css/").mkdir();
                    }
                } catch (SecurityException e) {
                    e.printStackTrace();
                }
                try {
                    if (!(new File("../js/").isDirectory())) {
                        new File("../js/").mkdir();
                    }
                } catch (SecurityException e) {
                    e.printStackTrace();
                }
                try {
                    if (!(new File("../images/").isDirectory())) {
                        new File("../images/").mkdir();
                    }
                } catch (SecurityException e) {
                    e.printStackTrace();
                }


                //now download the resources needed
                try {
                    getUnprotectedSource("http://210.42.121.134/css/style.css?v=2.002", "../css/style.css");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    getUnprotectedSource("http://210.42.121.134/css/tab.css?v=2.002", "../css/tab.css");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    getUnprotectedSource("http://210.42.121.134/js/jquery.tools.min.js", "../js/jquery.tools.min.js");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    getUnprotectedSource("http://210.42.121.134/js/table.js?v=2.002", "../js/table.js");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    getUnprotectedSource("http://210.42.121.134/images/btn_bg.png", "../images/btn_bg.png");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                    getUnprotectedSource("http://210.42.121.134/images/button_bg.png", "../images/button_bg.png");
                } catch (Exception e) {
                    e.printStackTrace();
                }



                JOptionPane.showConfirmDialog(null, "Succeed!\nFile: in [WebSpider] Directory,Svlt_QueryStuScore.html\nIf content is wrong, make sure your id, password and identifying code is correct, then refresh and try again!",
                        "choose one", JOptionPane.CANCEL_OPTION);
            }
        });


        //add listener to refresh button
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                idInput.setText("");
                pwdInput.setText("");
                codeInput.setText("");

                //to get first cookie
                URL urlRefresh = null;
                try {
                    urlRefresh = new URL("http://210.42.121.134/");
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                HttpURLConnection connectionRefresh = null;
                try {
                    connectionRefresh = (HttpURLConnection) urlRefresh.openConnection();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    connectionRefresh.setRequestMethod("GET");
                } catch (ProtocolException e) {
                    e.printStackTrace();
                }
                connectionRefresh.setDoOutput(true);
                connectionRefresh.setDoInput(true);
                connectionRefresh.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
                connectionRefresh.addRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
                connectionRefresh.addRequestProperty("Accept-Language", "zh-CN,zh;q=0.8");
                connectionRefresh.addRequestProperty("Connection", "keep-alive");
                connectionRefresh.addRequestProperty("Host", "210.42.121.134");
                connectionRefresh.addRequestProperty("Upgrade-Insecure-Requests", "1");
                connectionRefresh.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36");

                try {
                    connectionRefresh.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                cookie = connectionRefresh.getHeaderField("Set-Cookie");
                BufferedReader bufferedReaderRefresh = null;
                try {
                    bufferedReaderRefresh = new BufferedReader(new InputStreamReader(connectionRefresh.getInputStream()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String lineRefresh = "";
                FileOutputStream fileRefresh = null;
                try {
                    fileRefresh = new FileOutputStream("./Login.html");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                while (lineRefresh != null) {
                    try {
                        lineRefresh = bufferedReaderRefresh.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    //System.out.println(line);
                    if (lineRefresh != null) {
                        try {
                            fileRefresh.write(lineRefresh.getBytes());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                try {
                    bufferedReaderRefresh.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }


                //use first cookie(we get it above) to get identifying code
                URL url1Refresh = null;
                try {
                    url1Refresh = new URL("http://210.42.121.134/servlet/GenImg");
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                URLConnection conRefresh = null;
                try {
                    conRefresh = url1Refresh.openConnection();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                conRefresh.setDoInput(true);
                conRefresh.setDoOutput(true);
                conRefresh.addRequestProperty("Accept", "image/webp,image/*,*/*;q=0.8");
                conRefresh.addRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
                conRefresh.addRequestProperty("Accept-Language", "zh-CN,zh;q=0.8");
                conRefresh.addRequestProperty("Connection", "keep-alive");
                conRefresh.addRequestProperty("Cookie", cookie);
                conRefresh.addRequestProperty("Host", "210.42.121.134");
                conRefresh.addRequestProperty("Referer", "http://210.42.121.134/");
                conRefresh.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36");
                try {
                    conRefresh.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                InputStream isRefresh = null;
                try {
                    isRefresh = conRefresh.getInputStream();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                cookie = conRefresh.getHeaderField("Set-Cookie");
                byte[] bsRefresh = new byte[1024];
                int lenRefresh = 0;
                File sfRefresh = new File("./");
                if(!sfRefresh.exists()) {
                    sfRefresh.mkdirs();
                }
                OutputStream osRefresh = null;
                try {
                    //download identifying code image
                    osRefresh = new FileOutputStream(sfRefresh.getPath()+"\\"+ "identifying_image.jpeg");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                while (lenRefresh != -1) {
                    try {
                        lenRefresh = isRefresh.read(bsRefresh);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (lenRefresh != -1) {
                        try {
                            osRefresh.write(bsRefresh, 0, lenRefresh);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                try {
                    osRefresh.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    isRefresh.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                //show the downloaded identifying code image on my windows
                Image imageRefresh = null;
                try {
                    imageRefresh = ImageIO.read(new File("./identifying_image.jpeg"));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                jPanel.getGraphics().drawImage(imageRefresh, 0, 0, null);
            }
        });


        //to get first cookie
        URL url = null;
        try {
            url = new URL("http://210.42.121.134/");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            connection.setRequestMethod("GET");
        } catch (ProtocolException e) {
            e.printStackTrace();
        }
        connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
        connection.addRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
        connection.addRequestProperty("Accept-Language", "zh-CN,zh;q=0.8");
        connection.addRequestProperty("Connection", "keep-alive");
        connection.addRequestProperty("Host", "210.42.121.134");
        connection.addRequestProperty("Upgrade-Insecure-Requests", "1");
        connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36");

        try {
            connection.connect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        cookie = connection.getHeaderField("Set-Cookie");
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        String line = "";
        FileOutputStream file = null;
        try {
            file = new FileOutputStream("./Login.html");
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (line != null) {
            try {
                line = bufferedReader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            //System.out.println(line);
            if (line != null) {
                try {
                    file.write(line.getBytes());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        try {
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


        //use first cookie(we get it above) to get identifying code
        URL url1 = null;
        try {
            url1 = new URL("http://210.42.121.134/servlet/GenImg");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        URLConnection con = null;
        try {
            con = url1.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
        con.setDoInput(true);
        con.setDoOutput(true);
        con.addRequestProperty("Accept", "image/webp,image/*,*/*;q=0.8");
        con.addRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
        con.addRequestProperty("Accept-Language", "zh-CN,zh;q=0.8");
        con.addRequestProperty("Connection", "keep-alive");
        con.addRequestProperty("Cookie", cookie);
        con.addRequestProperty("Host", "210.42.121.134");
        con.addRequestProperty("Referer", "http://210.42.121.134/");
        con.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36");
        try {
            con.connect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        InputStream is = null;
        try {
            is = con.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        cookie = con.getHeaderField("Set-Cookie");
        byte[] bs = new byte[1024];
        int len = 0;
        File sf=new File("./");
        if(!sf.exists()) {
            sf.mkdirs();
        }
        OutputStream os = null;
        try {
            //download identifying code image
            os = new FileOutputStream(sf.getPath()+"\\"+ "identifying_image.jpeg");
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (len != -1) {
            try {
                len = is.read(bs);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (len != -1) {
                try {
                    os.write(bs, 0, len);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        try {
            os.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //show the downloaded identifying code image on my windows
        Image image = null;
        try {
            image = ImageIO.read(new File("./identifying_image.jpeg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        jPanel.getGraphics().drawImage(image, 0, 0, null);
    }
}
