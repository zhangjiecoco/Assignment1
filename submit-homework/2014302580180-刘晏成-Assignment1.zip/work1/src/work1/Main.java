package work1;

import java.io.File;

public class Main {
	public static void main(String[] args){
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0";
		
		HttpRequest response = HttpRequest.get(url).header("cookie","JSESSIONID=7DE0E075B4A494FBD56B74AD1DA046EA.tomcat2");
		
		response.receive(new File("grade.html"));
	}

}
